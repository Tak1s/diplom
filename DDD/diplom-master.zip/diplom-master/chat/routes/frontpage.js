exports.get = function(req, res){
    res.render('front_page');
}