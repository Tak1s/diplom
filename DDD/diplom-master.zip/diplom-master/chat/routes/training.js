exports.get = function(req, res){
    res.render('training_page');
}