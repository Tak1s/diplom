exports.get = function(req, res){
    res.render('chat_page');
}